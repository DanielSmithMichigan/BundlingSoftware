function memory() {
	this.footer_showing = false;
}