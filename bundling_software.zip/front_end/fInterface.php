<?php
	class fInterface {
	}
?>