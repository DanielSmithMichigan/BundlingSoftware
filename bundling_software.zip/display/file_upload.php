<div class="container">
	<form id="file_upload_form" enctype="multipart/form-data" >
		<div class="form-group">
			<label for="file_uploader"><h3>File Input</h3></label>
			<input type="file" id="file_uploader">
			<p class="help-block">Select the excel file which will be used to replace the current parts list</p>
		</div>
	</form>
</div>