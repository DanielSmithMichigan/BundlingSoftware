<div class="section">
	<div class="hero-unit">
		<!-- __TOP_SECTION__ -->
	</div>
</div>
<div class="selection_body">
	<!-- __BOTTOM_SECTION__ -->
</div>