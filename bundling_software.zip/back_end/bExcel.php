<?php 
	require_once dirname(__FILE__) . '/../Includes/PHPExcel/IOFactory.php';
	class bExcel {
		public function loadFromExcel() {
		
		}
	}
?>